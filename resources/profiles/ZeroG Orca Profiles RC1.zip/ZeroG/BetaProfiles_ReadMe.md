If you previously installed the Beta Profile from ZeroG Discord you will have to clean up Orca for the New ones to work.

If you do not clean older files Orca Slicer won't be able to load the new ones.

Windows users go to:
%appData%\OrcaSlicer\system (Usualy located at: C:\Users\username\AppData\Roaming\OrcaSlicer\system)
Delete the file ZeroG.json and the Folder ZeroG.